import asyncHandler from "../middlewares/AsyncHandler";
import { Request, Response, Router } from "express";
import { dbCheck, dbDelete, validate } from "../middlewares/Validator";
import {
  idValidater,
  addEventActivityValidator,
  editEventActivityValidator,
} from "../validators";
import { EventActivity, IEventActivity } from "../models";
import { BadRequest } from "../customErrors";

const router = Router();

type ParamsWithId = {
  id: string;
};

type EventActivityFilter = {
  name?: string;
  description?: string;
  fromDate?: string;
  toDate?: string;
  limit: string;
  page: string;
};

type AddEventActivity = IEventActivity & {};

// get / filter all event activities
router.get(
  "/",
  asyncHandler(async (req: Request, res: Response) => {
    const { limit, page, name, fromDate, toDate, description } =
      req.query as EventActivityFilter;

    let toQuery = {};

    if (name) toQuery = { ...toQuery, name: { $regex: name, $options: "i" } };

    if (description)
      toQuery = {
        ...toQuery,
        description: { $regex: description, $options: "i" },
      };

    if (fromDate && toDate) {
      if (new Date(fromDate) > new Date(toDate)) {
        throw new BadRequest("From date must be less than to date");
      }
      toQuery = {
        ...toQuery,
        when: {
          $gte: new Date(fromDate),
          $lte: new Date(toDate),
        },
      };
    } else if (fromDate) {
      toQuery = {
        ...toQuery,
        when: {
          $gte: new Date(fromDate),
        },
      };
    } else if (toDate) {
      toQuery = {
        ...toQuery,
        when: {
          $lte: new Date(toDate),
        },
      };
    }

    const eventActivityCount = await EventActivity.countDocuments(toQuery);

    const eventActivities = await EventActivity.aggregate([
      { $match: toQuery },
      { $skip: (parseInt(page) - 1) * parseInt(limit) },
      { $limit: parseInt(limit) },
      {
        $lookup: {
          from: "donors",
          localField: "addedBy",
          foreignField: "_id",
          as: "addedBy",
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          description: 1,
          when: {
            $dateToString: {
              format: "%d-%m-%Y",
              date: "$when",
            },
          },
          addedBy: {
            $arrayElemAt: ["$addedBy", 0],
          },
        },
      },
      {
        $project: {
          _id: 1,
          name: 1,
          description: 1,
          when: 1,
          addedBy: {
            _id: 1,
            name: 1,
            email: 1,
          },
        },
      },
    ]);

    res.json({
      data: eventActivities,
      hasNext: parseInt(limit) * parseInt(page) < eventActivityCount,
      hasPrev: parseInt(page) > 1,
    });
  })
);

// add new event activity
router.post(
  "/",
  validate(addEventActivityValidator),
  asyncHandler(async (req: Request, res: Response) => {
    const { name, description, when } = req.body as AddEventActivity;
    const { _id: userId } = req.user;

    await EventActivity.create({
      name,
      description,
      when,
      addedBy: userId,
    });

    res.json({ msg: "Event Activity added successfully" });
  })
);

// update event activity
router.put(
  "/:id",
  validate(idValidater),
  validate(editEventActivityValidator),
  dbCheck(EventActivity),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params as ParamsWithId;

    await EventActivity.findByIdAndUpdate(id, req.body);

    res.json({ msg: "Event Activity updated successfully" });
  })
);

// delete orphan
router.delete(
  "/:id",
  validate(idValidater),
  dbDelete(EventActivity),
  asyncHandler(async (_: Request, res: Response) => {
    res.json({ msg: "Event Activity deleted successfully" });
  })
);

export default router;
