import asyncHandler from "../middlewares/AsyncHandler";
import { Request, Response, Router } from "express";
import {
  dbCheck,
  dbCheckBody,
  dbDelete,
  validate,
} from "../middlewares/Validator";
import {
  idValidater,
  addGalleryValidator,
  editGalleryValidator,
} from "../validators";
import { IGallery, Gallery } from "../models";
import dayjs from "dayjs";
import { uploadLocal } from "../constants/lib";
import CONFIG from "../config";
import fs from "fs/promises";
import path from "path";
import { BadRequest } from "../customErrors";
import { Gender } from "../types";
import { ObjectId } from "mongodb";

const router = Router();

type ParamsWithId = {
  id: string;
};

type GalleryFilter = {
  title?: string;
  description?: string;
  limit: string;
  page: string;
};

// get / filter all orphans
router.get(
  "/",
  asyncHandler(async (req: Request, res: Response) => {
    const { limit, page, description, title } = req.query as GalleryFilter;

    let toQuery = {};

    if (title)
      toQuery = { ...toQuery, title: { $regex: title, $options: "i" } };

    if (description)
      toQuery = {
        ...toQuery,
        description: { $regex: description, $options: "i" },
      };

    const galleryImagesount = await Gallery.countDocuments(toQuery);

    const galleryImages = await Gallery.aggregate([
      { $match: toQuery },
      { $sort: { updatedAt: -1 } },
      { $skip: (parseInt(page) - 1) * parseInt(limit) },
      { $limit: parseInt(limit) },
      {
        $project: {
          _id: 1,
          title: 1,
          description: 1,
          image: 1,
        },
      },
    ]);

    res.json({
      data: galleryImages,
      hasNext: parseInt(limit) * parseInt(page) < galleryImagesount,
      hasPrev: parseInt(page) > 1,
    });
  })
);

// add new image to gallery
router.post(
  "/",
  uploadLocal.single("image"),
  validate(addGalleryValidator),
  dbCheckBody(Gallery, "title"),
  asyncHandler(async (req: Request, res: Response) => {
    try {
      const { title, description } = req.body as IGallery;

      const image = req.file as Express.Multer.File;

      await Gallery.create({
        title,
        description,
        image: `${CONFIG.HOST}/static/uploads/${image.filename}`,
      });

      res.json({ msg: "Image in gallery added successfully" });
    } catch (error) {
      if (req.file) {
        const stat = await fs.stat(req.file.path);
        if (stat.isFile()) {
          await fs.unlink(req.file.path);
        }
      }

      throw error;
    }
  })
);

// update image to gallery
router.put(
  "/:id",
  uploadLocal.single("image"),
  validate(idValidater),
  validate(editGalleryValidator),
  dbCheck(Gallery),
  asyncHandler(async (req: Request, res: Response) => {
    try {
      const { id } = req.params as ParamsWithId;

      const image = req.file as Express.Multer.File;

      // if new image is uploaded and old image exists, delete old image
      // and update new image url in db
      if (image) {
        const { image: oldImageUrl } = req.prevObject as IGallery;

        if (oldImageUrl) {
          const split = oldImageUrl.split("/");
          const imageName = split[split.length - 1];
          const imagePath = path.join(
            process.cwd(),
            "public",
            "uploads",
            imageName
          );
          const stat = await fs.stat(imagePath);
          if (stat.isFile()) {
            await fs.unlink(imagePath);
          }
        }

        req.body.image = `${CONFIG.HOST}/static/uploads/${image.filename}`;
      }

      await Gallery.findByIdAndUpdate(id, { ...req.body });

      res.json({ msg: "Image in gallery updated successfully" });
    } catch (error) {
      if (req.file) {
        const stat = await fs.stat(req.file.path);
        if (stat.isFile()) {
          await fs.unlink(req.file.path);
        }
      }

      throw error;
    }
  })
);

// delete orphan
router.delete(
  "/:id",
  validate(idValidater),
  dbDelete(Gallery),
  asyncHandler(async (req: Request, res: Response) => {
    const { image } = req.prevObject as IGallery;

    if (image) {
      const split = image.split("/");
      const imageName = split[split.length - 1];
      const imagePath = path.join(
        process.cwd(),
        "public",
        "uploads",
        imageName
      );
      const stat = await fs.stat(imagePath);
      if (stat.isFile()) {
        await fs.unlink(imagePath);
      }
    }

    res.json({ msg: "Image in gallery deleted successfully" });
  })
);

export default router;
