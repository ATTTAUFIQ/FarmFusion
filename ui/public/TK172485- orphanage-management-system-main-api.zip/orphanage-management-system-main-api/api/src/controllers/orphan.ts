import asyncHandler from "../middlewares/AsyncHandler";
import { Request, Response, Router } from "express";
import {
  dbCheck,
  dbCheckBody,
  dbDelete,
  validate,
} from "../middlewares/Validator";
import {
  idValidater,
  addOrphanValidator,
  editOrphanValidator,
  updateFamilyValidator,
} from "../validators";
import { FamilyUpdate, IOrphan, Orphan } from "../models";
import dayjs from "dayjs";
import { sendMail, uploadLocal } from "../constants/lib";
import CONFIG from "../config";
import fs from "fs/promises";
import path from "path";
import { BadRequest } from "../customErrors";
import { Gender } from "../types";
import { ObjectId } from "mongodb";

const router = Router();

type ParamsWithId = {
  id: string;
};

type OrphanFilter = {
  name?: string;
  fromAge?: string;
  toAge?: string;
  gender?: Gender;
  address?: string;
  state?: string;
  city?: string;
  limit: string;
  page: string;
};

type FamilyUpdate = {
  description: string;
  orphanId: string;
};

// get / filter all orphans
router.get(
  "/",
  asyncHandler(async (req: Request, res: Response) => {
    const { limit, page, address, fromAge, toAge, city, gender, name, state } =
      req.query as OrphanFilter;

    let toQuery = {};

    if (name) toQuery = { ...toQuery, name: { $regex: name, $options: "i" } };

    if (gender) toQuery = { ...toQuery, gender };

    if (address)
      toQuery = { ...toQuery, address: { $regex: address, $options: "i" } };

    if (state)
      toQuery = { ...toQuery, state: { $regex: state, $options: "i" } };

    if (city) toQuery = { ...toQuery, city: { $regex: city, $options: "i" } };

    if (fromAge && toAge) {
      toQuery = {
        ...toQuery,
        age: { $gte: parseInt(fromAge), $lte: parseInt(toAge) },
      };
    } else if (fromAge) {
      toQuery = {
        ...toQuery,
        age: { $gte: parseInt(fromAge) },
      };
    } else if (toAge) {
      toQuery = {
        ...toQuery,
        age: { $lte: parseInt(toAge) },
      };
    }

    const orphanCount = await Orphan.countDocuments(toQuery);

    const orphans = await Orphan.aggregate([
      { $match: toQuery },
      { $sort: { createdAt: -1 } },
      { $skip: (parseInt(page) - 1) * parseInt(limit) },
      { $limit: parseInt(limit) },
      {
        $project: {
          _id: 1,
          name: 1,
          dob: {
            $dateToString: { format: "%d-%m-%Y", date: "$dob" },
          },
          age: 1,
          image: 1,
          familyDetails: 1,
        },
      },
    ]);

    res.json({
      data: orphans,
      hasNext: parseInt(limit) * parseInt(page) < orphanCount,
      hasPrev: parseInt(page) > 1,
    });
  })
);

// get orphan by id
router.get(
  "/:id",
  validate(idValidater),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params as ParamsWithId;

    const projection = {
      _id: 1,
      name: 1,
      dob: {
        $dateToString: { format: "%d-%m-%Y", date: "$dob" },
      },
      age: 1,
      image: 1,
      familyDetails: 1,
    };

    const orphans = await Orphan.aggregate([
      {
        $match: {
          _id: ObjectId.createFromHexString(id),
        },
      },
      {
        $project: projection,
      },
    ]);

    if (orphans.length === 0) {
      throw new BadRequest(`Orphan with id ${id} not found`);
    }

    res.json(orphans[0]);
  })
);

router.post(
  "/:id/update-family",
  validate(updateFamilyValidator),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params as ParamsWithId;
    const { description } = req.body as FamilyUpdate;

    const orphan = await Orphan.findById(id);

    if (!orphan) {
      throw new BadRequest(`Orphan with id ${id} not found`);
    }

    const familyDetails = orphan.familyDetails || [];

    if (familyDetails.length === 0) {
      throw new BadRequest(`Orphan has no family members`);
    }

    const firstFamilyMember = familyDetails[0];

    if (!firstFamilyMember.email) {
      throw new BadRequest(`Family member has no email`);
    }

    let template = await fs.readFile(
      path.join(process.cwd(), "templates", "family-update.html"),
      "utf-8"
    );

    template = template.replace("{{description}}", description);

    await sendMail(
      firstFamilyMember.email,
      `${orphan.name} update`,
      template,
      true
    );

    await FamilyUpdate.create({ description, orphanId: id });

    res.json({ msg: "Details sent to family successfully" });
  })
);

// add new orphan
router.post(
  "/",
  uploadLocal.single("image"),
  validate(addOrphanValidator),
  dbCheckBody(Orphan, "name"),
  asyncHandler(async (req: Request, res: Response) => {
    try {
      const { dob } = req.body as IOrphan;

      const image = req.file as Express.Multer.File;

      req.body.familyDetails = JSON.parse(req.body.familyDetails);

      req.body.age = dayjs().diff(dob, "year");

      if (image) {
        req.body.image = `${CONFIG.HOST}/static/uploads/${image.filename}`;
      }

      await Orphan.create(req.body);

      res.json({ msg: "Orphan added successfully" });
    } catch (error) {
      if (req.file) {
        const stat = await fs.stat(req.file.path);
        if (stat.isFile()) {
          await fs.unlink(req.file.path);
        }
      }

      throw error;
    }
  })
);

// update orphan
router.put(
  "/:id",
  uploadLocal.single("image"),
  validate(idValidater),
  validate(editOrphanValidator),
  dbCheck(Orphan),
  asyncHandler(async (req: Request, res: Response) => {
    try {
      const { id } = req.params as ParamsWithId;
      const { dob } = req.body as IOrphan;

      const image = req.file as Express.Multer.File;

      if (req.body.familyDetails) {
        req.body.familyDetails = JSON.parse(req.body.familyDetails);
      }

      // if new image is uploaded and old image exists, delete old image
      // and update new image url in db
      if (image) {
        const { image: oldImageUrl } = req.prevObject as IOrphan;

        if (oldImageUrl) {
          const split = oldImageUrl.split("/");
          const imageName = split[split.length - 1];
          const imagePath = path.join(
            process.cwd(),
            "public",
            "uploads",
            imageName
          );
          const stat = await fs.stat(imagePath);
          if (stat.isFile()) {
            await fs.unlink(imagePath);
          }
        }

        req.body.image = `${CONFIG.HOST}/static/uploads/${image.filename}`;
      }

      if (dob) {
        req.body.age = dayjs().diff(req.body.dob, "year");
      }

      await Orphan.findByIdAndUpdate(id, { ...req.body });

      res.json({ msg: "Orphan updated successfully" });
    } catch (error) {
      if (req.file) {
        const stat = await fs.stat(req.file.path);
        if (stat.isFile()) {
          await fs.unlink(req.file.path);
        }
      }

      throw error;
    }
  })
);

// delete orphan
router.delete(
  "/:id",
  validate(idValidater),
  dbDelete(Orphan),
  asyncHandler(async (_: Request, res: Response) => {
    res.json({ msg: "Orphan deleted successfully" });
  })
);

export default router;
