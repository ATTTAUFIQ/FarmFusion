import asyncHandler from "../middlewares/AsyncHandler";
import { Request, Response, Router } from "express";
import { validate } from "../middlewares/Validator";
import {
  idValidater,
  addDonationValidator,
  editDonationValidator,
  addDonationDonorValidator,
} from "../validators";
import { Donation, IDonation } from "../models";
import { BadRequest } from "../customErrors";
import { DonationStatus, RoleEnum } from "../types";
import { ObjectId } from "mongodb";

const router = Router();

type ParamsWithId = {
  id: string;
};

type AddDonation = IDonation & {};

type DonationFilter = {
  why?: string;
  orphanId?: string;
  fromAmount?: string;
  toAmount?: string;
  status?: DonationStatus;
  limit: string;
  page: string;
};

// get / filter all donations
router.get(
  "/",
  asyncHandler(async (req: Request, res: Response) => {
    const { limit, page, fromAmount, orphanId, status, toAmount, why } =
      req.query as DonationFilter;

    let toQuery = {};

    if (why) toQuery = { ...toQuery, why: { $regex: why, $options: "i" } };

    if (status) toQuery = { ...toQuery, status };

    if (orphanId)
      toQuery = {
        ...toQuery,
        orphanId: ObjectId.createFromHexString(orphanId),
      };

    if (fromAmount && toAmount) {
      if (parseInt(fromAmount) > parseInt(toAmount)) {
        throw new BadRequest("fromPrice should be less than toPrice");
      }
      toQuery = {
        ...toQuery,
        amount: { $gte: parseInt(fromAmount), $lte: parseInt(toAmount) },
      };
    } else if (fromAmount) {
      toQuery = {
        ...toQuery,
        amount: { $gte: parseInt(fromAmount) },
      };
    } else if (toAmount) {
      toQuery = {
        ...toQuery,
        amount: { $lte: parseInt(toAmount) },
      };
    }

    const donationCount = await Donation.countDocuments(toQuery);

    const donations = await Donation.aggregate([
      { $match: toQuery },
      { $skip: (parseInt(page) - 1) * parseInt(limit) },
      { $limit: parseInt(limit) },
      {
        $lookup: {
          from: "orphans",
          localField: "orphanId",
          foreignField: "_id",
          as: "orphan",
        },
      },
      {
        $project: {
          _id: 1,
          amount: 1,
          why: 1,
          status: 1,
          orphan: {
            $arrayElemAt: ["$orphan", 0],
          },
          donors: 1,
        },
      },
      {
        $project: {
          _id: 1,
          amount: 1,
          why: 1,
          status: 1,
          orphan: {
            _id: 1,
            name: 1,
            dob: {
              $dateToString: { format: "%d-%m-%Y", date: "$orphan.dob" },
            },
          },
          donors: 1,
        },
      },
    ]);

    res.json({
      data: donations,
      hasNext: parseInt(limit) * parseInt(page) < donationCount,
      hasPrev: parseInt(page) > 1,
    });
  })
);

// add new donation
router.post(
  "/",
  validate(addDonationValidator),
  asyncHandler(async (req: Request, res: Response) => {
    const { why, amount, orphanId } = req.body as AddDonation;

    await Donation.create({
      why,
      amount,
      orphanId,
    });

    res.json({ msg: "Donation request raised successfully" });
  })
);

// update orphan
router.put(
  "/:id",
  validate(idValidater),
  validate(editDonationValidator),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params as ParamsWithId;
    const { why, orphanId } = req.body as AddDonation;

    const donation = await Donation.findById(id);

    if (!donation) {
      throw new BadRequest("Donation not found");
    }

    if (donation.status === DonationStatus.COMPLETED) {
      throw new BadRequest("Donation already completed you cannot update now");
    }

    if (why) donation.why = why;
    if (orphanId) donation.orphanId = orphanId;

    await donation.save();

    res.json({ msg: "Donation updated succesfully" });
  })
);

// donate
router.post(
  "/:id/donate",
  validate(idValidater),
  validate(addDonationDonorValidator),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params as ParamsWithId;
    const { amount } = req.body as AddDonation;
    const { name, email, role } = req.user;

    if (role !== RoleEnum.DONOR) {
      throw new BadRequest("Only donors can donate");
    }

    const donation = await Donation.findById(id);

    if (!donation) {
      throw new BadRequest("Donation not found");
    }

    if (donation.donors === undefined) {
      donation.donors = [];
    }

    donation.donors.push({
      name,
      email,
      amount,
    });

    const donationAmount = donation.donors.reduce(
      (acc, curr) => acc + curr.amount,
      0
    );

    if (donationAmount >= donation.amount) {
      donation.status = DonationStatus.COMPLETED;
    }

    await donation.save();

    res.json({ msg: "Thanks for your donation , with love from orphans" });
  })
);

// delete donation
router.delete(
  "/:id",
  validate(idValidater),
  asyncHandler(async (req: Request, res: Response) => {
    const { id } = req.params as ParamsWithId;

    const donation = await Donation.findById(id);

    if (!donation) {
      throw new BadRequest("Donation not found");
    }

    if (donation.status === DonationStatus.COMPLETED) {
      throw new BadRequest("Donation already completed");
    }

    if (donation.donors) {
      if (donation.donors.length > 0) {
        throw new BadRequest(
          `Donation already started and has ${donation.donors.length} donations , you cannot delete now`
        );
      }
    }

    await donation.deleteOne();

    res.json({ msg: "Donation deleted successfully" });
  })
);

export default router;
