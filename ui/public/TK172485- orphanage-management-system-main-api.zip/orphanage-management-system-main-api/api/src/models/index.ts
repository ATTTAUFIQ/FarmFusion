/**
 * @fileoverview This file exports all the models in the models folder
 * @author YMTS <devteam@ymtsindia.in>
 */

export * from "./base.model";
export * from "./admin.model";
export * from "./staff.model";
export * from "./donor.model";
export * from "./orphan.model";
export * from "./event-activity.model";
export * from "./donation.model";
export * from "./gallery.model";
export * from "./family-update.model";
