import { Schema, model } from "mongoose";
import { IBaseUser, IbaseUserSchema } from "./base.model";

export interface IDonor extends IBaseUser {}

const donorSchema = new Schema(IbaseUserSchema, { timestamps: true });

export const Donor = model<IDonor>("donor", donorSchema);
