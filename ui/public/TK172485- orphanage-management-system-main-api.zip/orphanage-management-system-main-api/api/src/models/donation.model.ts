import { Document, Schema, model } from "mongoose";
import { DonationStatus } from "../types";

export interface DonationDonor {
  name: string;
  email: string;
  amount: number;
  when?: Date;
}

export interface IDonation extends Document {
  amount: number;
  why: string;
  orphanId: string;
  status: DonationStatus;
  donors?: DonationDonor[];
}

const donationSchema = new Schema(
  {
    amount: { type: Number, required: true },
    why: { type: String, required: true },
    orphanId: { type: Schema.Types.ObjectId, ref: "orphan" },
    status: {
      type: String,
      enum: Object.values(DonationStatus),
      default: DonationStatus.PENDING,
    },
    donors: [
      {
        name: { type: String, required: true },
        email: { type: String, required: true },
        amount: { type: Number, required: true },
        when: { type: Date, default: Date.now },
      },
    ],
  },
  { timestamps: true }
);

export const Donation = model<IDonation>("donation", donationSchema);
