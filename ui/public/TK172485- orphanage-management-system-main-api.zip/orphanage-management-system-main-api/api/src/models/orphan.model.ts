import { Document, Schema, model } from "mongoose";
import { Gender } from "../types";

export interface IFamilyDetail {
  name?: string;
  relation?: string;
  email?: string;
  phone?: string;
}

export interface IOrphan extends Document {
  name: string;
  dob: Date;
  gender: Gender;
  state: string;
  city: string;
  address: string;
  image?: string;
  familyDetails?: IFamilyDetail[];
}

const orphanSchema = new Schema(
  {
    name: { type: String, required: true },
    dob: { type: Date, required: true },
    age: { type: Number, required: true },
    image: { type: String },
    gender: { type: String, required: true, enum: Object.values(Gender) },
    state: { type: String, required: true },
    city: { type: String, required: true },
    address: { type: String, required: true },
    familyDetails: [
      {
        name: String,
        relation: String,
        email: String,
        phone: String,
      },
    ],
  },
  { timestamps: true }
);

export const Orphan = model<IOrphan>("orphan", orphanSchema);
