import { Document, Schema, model } from "mongoose";
import { IBaseUser, IbaseUserSchema } from "./base.model";

export interface IFamilyUpdate extends Document {
  description: string;
  orphanId: string;
}

const familyUpdateschema = new Schema(
  {
    description: { type: String, required: true },
    orphanId: { type: Schema.Types.ObjectId, ref: "orphan", required: true },
  },
  { timestamps: true }
);

export const FamilyUpdate = model<IFamilyUpdate>(
  "family-update",
  familyUpdateschema
);
