import { Document, Schema, model } from "mongoose";
import { EventStatus } from "../types";

export interface IEventActivity extends Document {
  name: string;
  description: string;
  when: Date;
  status: EventStatus;
  addedBy: string;
}

const eventActivitySchema = new Schema(
  {
    name: { type: String, required: true },
    description: { type: String, required: true },
    when: { type: Date, required: true },
    status: {
      type: String,
      required: true,
      enum: Object.values(EventStatus),
      default: EventStatus.PENDING,
    },
    addedBy: { type: Schema.Types.ObjectId, ref: "user", required: true },
  },
  { timestamps: true }
);

export const EventActivity = model<IEventActivity>(
  "event-activity",
  eventActivitySchema
);
