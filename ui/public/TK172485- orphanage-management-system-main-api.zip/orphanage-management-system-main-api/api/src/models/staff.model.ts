import { Schema, model } from "mongoose";
import { IBaseUser, IbaseUserSchema } from "./base.model";

export interface IStaff extends IBaseUser {}

const staffSchema = new Schema(IbaseUserSchema, { timestamps: true });

export const Staff = model<IStaff>("staff", staffSchema);
