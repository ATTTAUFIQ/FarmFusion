import { Schema } from "mongoose";

export type Role = "ADMIN" | "STAFF" | "DONOR";

export type TokenInfo = {
  _id: Schema.Types.ObjectId;
  email: string;
  name: string;
  role: Role;
};

export enum RoleEnum {
  ADMIN = "ADMIN",
  STAFF = "STAFF",
  DONOR = "DONOR",
}

export enum DonationStatus {
  PENDING = "PENDING",
  PROGRESS = "PROGRESS",
  COMPLETED = "COMPLETED",
}

export enum EventStatus {
  PENDING = "PENDING",
  ACCEPTED = "ACCEPTED",
}

export enum Gender {
  MALE = "MALE",
  FEMALE = "FEMALE",
  OTHER = "OTHER",
}
