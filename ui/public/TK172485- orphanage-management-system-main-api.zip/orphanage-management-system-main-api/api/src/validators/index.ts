import { param, body, query } from "express-validator";
import { Gender, RoleEnum as ROLES } from "../types";
import dayjs from "dayjs";
import timezone from "dayjs/plugin/timezone";
import { IFamilyDetail } from "../models";

dayjs.extend(timezone); // Extend dayjs with timezone plugin
// set dayjs to IST timezone
dayjs.tz.setDefault("Asia/Kolkata");

export const idValidater = [
  param("id").isMongoId().withMessage("Id must be a valid mongo id"),
];

export const roleValidater = [
  body("role")
    .notEmpty()
    .withMessage("Role is required")
    .isIn(Object.values(ROLES))
    .withMessage("Role must be in " + Object.values(ROLES).join(", ")),
];

export const roleParamsValidater = [
  query("role")
    .notEmpty()
    .withMessage("Role is required")
    .isIn(Object.values(ROLES))
    .withMessage("Role must be in " + Object.values(ROLES).join(", ")),
];

export const roleWithQParamsValidater = [
  query("role")
    .notEmpty()
    .withMessage("Role is required")
    .isIn(Object.values(ROLES))
    .withMessage("Role must be in " + Object.values(ROLES).join(", ")),

  query("q").optional().isString().withMessage("Query must be a string"),
];

export const addUserValidator = [
  body("name")
    .notEmpty()
    .withMessage("Name is required")
    .isString()
    .withMessage("Name must be a string"),
  body("email")
    .notEmpty()
    .withMessage("Email is required")
    .isEmail()
    .withMessage("Email must be a valid email"),
  body("password")
    .notEmpty()
    .withMessage("Password is required")
    .isLength({ min: 6, max: 10 })
    .withMessage("Password must be at least 6 characters long"),
  body("role")
    .notEmpty()
    .withMessage("Role is required")
    .isIn(Object.values(ROLES))
    .withMessage("Role must be in " + Object.values(ROLES).join(", ")),
];

export const editUserValidator = [
  body("name").optional().isString().withMessage("Name must be a string"),
  body("email").optional().isEmail().withMessage("Email must be a valid email"),
  body("password")
    .optional()
    .isLength({ min: 6, max: 10 })
    .withMessage("Password must be at least 6 characters long"),
  body("role")
    .notEmpty()
    .withMessage("Role is required")
    .isIn(Object.values(ROLES))
    .withMessage("Role must be in " + Object.values(ROLES).join(", ")),
];

export const loginValidator = [
  body("email").optional().isEmail().withMessage("Email must be a valid email"),
  body("password")
    .optional()
    .isLength({ min: 6, max: 10 })
    .withMessage("Password must be at least 6 characters long"),
  body("role")
    .notEmpty()
    .withMessage("Role is required")
    .isIn(Object.values(ROLES))
    .withMessage("Role must be in " + Object.values(ROLES).join(", ")),
];

export const addOrphanValidator = [
  body("name")
    .notEmpty()
    .withMessage("Name is required")
    .isString()
    .withMessage("Name must be a string"),
  body("dob")
    .notEmpty()
    .withMessage("Date of birth is required")
    .isDate()
    .withMessage("Date of birth must be a valid date")
    .custom((dob) => {
      return dayjs().diff(dob, "year") >= 0;
    })
    .withMessage("Date of birth must be not in future"),
  body("gender")
    .notEmpty()
    .withMessage("Gender is required")
    .isIn(Object.values(Gender))
    .withMessage("Gender must be in " + Object.values(Gender).join(", ")),
  body("state")
    .notEmpty()
    .withMessage("State is required")
    .isString()
    .withMessage("State must be a string"),
  body("city")
    .notEmpty()
    .withMessage("City is required")
    .isString()
    .withMessage("City must be a string"),
  body("address")
    .notEmpty()
    .withMessage("Address is required")
    .isString()
    .withMessage("Address must be a string"),
  body("familydetails")
    .optional()
    .custom((value) => {
      if (!value) return false;
      const familyKeys = ["name", "relation", "age", "email"];
      const familyDetailsString = value as string;
      const familyDetails = JSON.parse(familyDetailsString) as IFamilyDetail[];
      return familyDetails.every((family) => {
        return familyKeys.every((key) => {
          return key in family;
        });
      });
    })
    .withMessage(
      "Family details must be an array of objects of family members"
    ),
  body("image")
    .custom((_, { req }) => {
      const file = req.file as Express.Multer.File;
      if (!file) return false;
      const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
      return allowedTypes.includes(file.mimetype);
    })
    .withMessage("Image must be a of valid image type"),
];

export const editOrphanValidator = [
  body("name").optional().isString().withMessage("Name must be a string"),
  body("dob")
    .optional()
    .isDate()
    .withMessage("Date of birth must be a valid date")
    .custom((dob) => {
      return dayjs().diff(dob, "year") >= 0;
    })
    .withMessage("Date of birth must be not in future"),
  body("gender")
    .optional()
    .isIn(Object.values(Gender))
    .withMessage("Gender must be in " + Object.values(Gender).join(", ")),
  body("state").optional().isString().withMessage("State must be a string"),
  body("city").optional().isString().withMessage("City must be a string"),
  body("address").optional().isString().withMessage("Address must be a string"),
  body("familydetails")
    .optional()
    .custom((value) => {
      if (!value) return false;
      const familyKeys = ["name", "relation", "age", "email"];
      const familyDetailsString = value as string;
      const familyDetails = JSON.parse(familyDetailsString) as IFamilyDetail[];
      return familyDetails.every((family) => {
        return familyKeys.every((key) => {
          return key in family;
        });
      });
    })
    .withMessage(
      "Family details must be an array of objects of family members"
    ),
  body("image")
    .custom((_, { req }) => {
      const file = req.file as Express.Multer.File;
      if (!file) return false;
      const allowedTypes = ["image/jpeg", "image/png", "image/jpg"];
      return allowedTypes.includes(file.mimetype);
    })
    .withMessage("Image must be a of valid image type"),
];

export const addEventActivityValidator = [
  body("name")
    .notEmpty()
    .withMessage("Name is required")
    .isString()
    .withMessage("Name must be a string"),
  body("description")
    .notEmpty()
    .withMessage("Description is required")
    .isString()
    .withMessage("Description must be a string"),
  body("when")
    .notEmpty()
    .withMessage("When is required")
    .isDate()
    .withMessage("When must be a valid date")
    .custom((when) => {
      // Check if when is a future date
      return dayjs().diff(when, "day") >= 0;
    })
    .withMessage("When must be a future date"),
];

export const editEventActivityValidator = [
  body("name").optional().isString().withMessage("Name must be a string"),
  body("description")
    .optional()
    .isString()
    .withMessage("Description must be a string"),
  body("when")
    .optional()
    .isDate()
    .withMessage("When must be a valid date")
    .custom((when) => {
      return dayjs().diff(when, "day") >= 0;
    })
    .withMessage("When must be a future date"),
];

export const addDonationValidator = [
  body("amount")
    .notEmpty()
    .withMessage("Amount is required")
    .isNumeric()
    .withMessage("Amount must be a number"),
  body("why")
    .notEmpty()
    .withMessage("Why is required")
    .isString()
    .withMessage("Why must be a string"),
  body("orphanId")
    .notEmpty()
    .withMessage("Orphan id is required")
    .isMongoId()
    .withMessage("Orphan id must be a valid mongo id"),
];

export const editDonationValidator = [
  body("amount").optional().isNumeric().withMessage("Amount must be a number"),
  body("why")
    .notEmpty()
    .withMessage("Why is required")
    .isString()
    .withMessage("Why must be a string"),
];

export const addDonationDonorValidator = [
  body("amount")
    .notEmpty()
    .withMessage("Amount is required")
    .isNumeric()
    .withMessage("Amount must be a number"),
];

export const addGalleryValidator = [
  body("title")
    .notEmpty()
    .withMessage("Title is required")
    .isString()
    .withMessage("Title must be a string"),
  body("description")
    .optional()
    .isString()
    .withMessage("Description must be a string"),
  body("image")
    .custom((_, { req }) => {
      const file = req.file as Express.Multer.File;
      if (!file) return false;
      const allowedTypes = [
        "image/jpeg",
        "image/png",
        "image/jpg",
        "image/webp",
      ];
      return allowedTypes.includes(file.mimetype);
    })
    .withMessage("Image must be a of valid image type"),
];

export const editGalleryValidator = [
  body("title").optional().isString().withMessage("Title must be a string"),
  body("description")
    .optional()
    .isString()
    .withMessage("Description must be a string"),
  body("image")
    .custom((_, { req }) => {
      const file = req.file as Express.Multer.File;
      if (!file) return false;
      const allowedTypes = [
        "image/jpeg",
        "image/png",
        "image/jpg",
        "image/webp",
      ];
      return allowedTypes.includes(file.mimetype);
    })
    .withMessage("Image must be a of valid image type"),
];

export const updateFamilyValidator = [
  body("description")
    .notEmpty()
    .withMessage("Description is required")
    .isString()
    .withMessage("Description must be a string"),
];
