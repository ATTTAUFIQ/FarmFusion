import { NextFunction, Request, Response } from "express";
import { ValidationChain, validationResult } from "express-validator";
import { Model } from "mongoose";
import { RoleEnum } from "../types";
import { Admin, Donor, Staff } from "../models";
import fs from "fs/promises";

export const validate = (validationChain: ValidationChain[]) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      await Promise.all(
        validationChain.map((validation) => validation.run(req))
      );
      const errors = validationResult(req);

      if (errors.isEmpty()) {
        next();
        return;
      }

      if (req.file) {
        const fileStat = await fs.stat(req.file.path);
        if (fileStat.isFile()) {
          await fs.unlink(req.file.path);
          console.log(`File on path ${req.file.path} deleted successfully`);
        }
      }

      return res.status(400).json({
        msg: errors.array().map((err: any) => {
          return {
            path: err.path,
            msg: err.msg,
          };
        }),
      });
    } catch (error: any) {
      if (req.file) {
        const fileStat = await fs.stat(req.file.path);
        if (fileStat.isFile()) {
          await fs.unlink(req.file.path);
          console.log(`File on path ${req.file.path} deleted successfully`);
        }
      }

      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbDelete = (model: typeof Model) => {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const result = await model.findById(id);
      if (result) {
        req.prevObject = result;
        await result.deleteOne();
        next();
        return;
      }
      return res
        .status(404)
        .json({ msg: `${model.modelName} with id : ${id} not found` });
    } catch (error: any) {
      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbUserDelete = () => {
  return async (req: any, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { role } = req.body;

      let modelToUse: typeof Model | null = null;

      switch (role) {
        case RoleEnum.ADMIN:
          modelToUse = Admin;
          break;
        case RoleEnum.STAFF:
          modelToUse = Staff;
          break;
        case RoleEnum.DONOR:
          modelToUse = Donor;
        default:
          break;
      }

      if (!modelToUse) {
        return res.status(400).json({ msg: "Invalid role" });
      }

      const result = await modelToUse.findById(id);

      if (result) {
        req.prevObject = result;
        await result.deleteOne();
        next();
        return;
      }

      return res.status(404).json({ msg: `${role} with id : ${id} not found` });
    } catch (error: any) {
      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbCheck = (model: typeof Model) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;

      const result = await model.findById(id);

      if (result) {
        req.prevObject = result;
        next();
        return;
      }

      if (req.file) {
        const fileStat = await fs.stat(req.file.path);
        if (fileStat.isFile()) {
          await fs.unlink(req.file.path);
          console.log(`File on path ${req.file.path} deleted successfully`);
        }
      }

      return res
        .status(404)
        .json({ msg: `${model.modelName} with id : ${id} not found` });
    } catch (error: any) {
      if (req.file) {
        const fileStat = await fs.stat(req.file.path);
        if (fileStat.isFile()) {
          await fs.unlink(req.file.path);
          console.log(`File on path ${req.file.path} deleted successfully`);
        }
      }
      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbCheckBody = (model: typeof Model, keyToCheck: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const key = req.body[keyToCheck as keyof typeof req.body];

      const result = await model.findOne({ [keyToCheck]: key });

      if (!result) {
        next();
        return;
      }

      return res.status(404).json({
        msg: `${model.modelName} with ${keyToCheck} : ${key} already exists`,
      });
    } catch (error: any) {
      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbCheckBodyUpdate = (model: typeof Model, keyToCheck: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      // this is for update
      const { id } = req.params;

      const key = req.body[keyToCheck as keyof typeof req.body];

      const result = await model.findOne({ [keyToCheck]: key });

      // we are checking if the result is the same as the id
      // if same we are allowing the update
      // else we are sending the error
      if (!result || result._id == id) {
        next();
        return;
      }

      return res.status(404).json({
        msg: `${model.modelName} with ${keyToCheck} : ${key} already exists`,
      });
    } catch (error: any) {
      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbUserCheck = (role: RoleEnum) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;

      let modelToUse: typeof Model | null = null;

      switch (role) {
        case RoleEnum.ADMIN:
          modelToUse = Admin;
          break;
        case RoleEnum.DONOR:
          modelToUse = Donor;
          break;
        case RoleEnum.STAFF:
          modelToUse = Staff;
        default:
          break;
      }

      if (!modelToUse) {
        return res.status(400).json({ msg: "Invalid role" });
      }

      const result = await modelToUse.findById(id);

      if (result) {
        next();
        return;
      }

      return res.status(404).json({ msg: `${role} with id : ${id} not found` });
    } catch (error: any) {
      res.status(500).json({ msg: error.message });
    }
  };
};

export const dbUserCheckV2 = (flip = false) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { id } = req.params;
      const { role, email } = req.body;

      let modelToUse: typeof Model | null = null;
      let result;

      if (flip) {
        switch (role) {
          case RoleEnum.ADMIN:
            modelToUse = Admin;
            break;
          case RoleEnum.STAFF:
            modelToUse = Staff;
            break;
          case RoleEnum.DONOR:
            modelToUse = Donor;
            break;
          default:
            break;
        }

        if (!modelToUse) {
          return res.status(400).json({ msg: "Invalid role" });
        }

        result = await modelToUse.findOne({ email });
      } else {
        switch (role) {
          case RoleEnum.ADMIN:
            modelToUse = Admin;
            break;
          case RoleEnum.DONOR:
            modelToUse = Donor;
            break;
          case RoleEnum.STAFF:
            modelToUse = Staff;
            break;
          default:
            break;
        }

        if (!modelToUse) {
          return res.status(400).json({ msg: "Invalid role" });
        }

        result = await modelToUse.findById(id);
      }

      if (flip) {
        if (!result) {
          next();
          return;
        }
        return res
          .status(400)
          .json({ msg: `${role} with email : ${email} already exists` });
      }

      if (result) {
        next();
        return;
      }

      return res.status(404).json({ msg: `${role} with id : ${id} not found` });
    } catch (error: any) {
      res.status(500).json({ msg: error.message });
    }
  };
};
